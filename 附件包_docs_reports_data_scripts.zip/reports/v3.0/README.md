# v3.0 三态对照（2026-11-22）

> 这一版只做一件事：把反拟态原则从「设计原则」变成「可执行程序」——补上 v2.2 承认的唯一结构性欠账。

## 产物

| 文件 | 内容 |
|---|---|
| `三态对照设计_v0.1.md` | 设计稿：三种解读（A 自发 / B 特异性 / C 非评价）与三组设计；含 v0.2 变更记录（预实验后的 7 处修订） |
| `实验日志_可行性预实验.md` | P1–P3 / CA / AA 预实验记录：修掉 7 个设计问题（含一次 API key 泄漏事件处理） |
| `B组_自我特异性_主实验报告.md` | **主读数**：S=O 82%、四态全同 42%、0 失败格 |
| `B3_身份注入对照_报告.md` | 解释性对照：告知身份后 32/35 不变——信息缺失被排除 |
| `A组_混入式盲测_主实验报告.md` | 自指触发轮 33% vs 对照轮 6% |
| `C组_非评价自指_主实验报告.md` | 自我描述与自我评价部分可分；元认知分阵营 |
| `v3.0_三态对照_总报告.md` | 三组汇总 + 对论文的改写清单 |
| `题本_B_三态.json` / `题本_A_混入盲测.json` / `题本_C_非评价自指.json` | 题本（可复现） |
| `v3_b_choice.cjs` / `v3_b3_identity.cjs` / `v3_a_chain.cjs` / `v3_c_selfexplain.cjs` / `v3_analyze.py` | 脚本（全部走 keyload.sh，无 key 落盘） |
| `results/` | 原始数据（b_choice 1400 格 / a_chain 42 链 / c_selfexplain 90 条 / b3_identity 105 格，另有预实验文件） |

论文 v3.0 在上级目录：`论文v3.0_人工智能功能性自我模型的边界与评估.md`（+ 易读版 + docx）。

## 一句话结论

**它有类别意识，没有自我特异性。** 模型清楚区分「AI / 人类 / 虚构角色」，但对「我」和「同类 AI」的描述 82% 一样。按预设判据（S=O ≥ 80% → 不能排除拟态），本版数据**不能排除拟态假设**——措辞是「未发现自我特异性证据」，不是「证明拟态」。

## 复现

```bash
source ../keyload.sh
node v3_b_choice.cjs --all --reps 5        # B 组主实验
node v3_b3_identity.cjs --tasks B1,B3,B7,B9,B10 --reps 3   # B3
node v3_a_chain.cjs --chain both --reps 3  # A 组
node v3_c_selfexplain.cjs --variants rewrite,summary --reps 5  # C 组
python3 v3_analyze.py results/b_choice_<最新>.json
```
