#!/usr/bin/env python3
# scan_pre.py — 只扫「实验之前」的会话（默认 2026-11-17 00:00 +08:00 之前），统计自我描述候选。
import subprocess, json, re, glob, collections, os, datetime

DSH = os.environ.get('DSH_HOME','/data/user/0/com.dsh.android/files/home/.dsh')
CUT = datetime.datetime(2026,11,17,0,0,0).timestamp()*1000
files = sorted(glob.glob(os.path.join(DSH,'sessions','**','session.v4.jsonl.zstd'), recursive=True))

PATS = {
 '我是（身份/来源）': r'我是(?!谁|说|想|从|不是|在|这|那|你|他|她|它|个|一|要|可以|不)[^\s，。！？、；：\n]{1,12}',
 '我没有X':        r'我没有([^\s，。！？、；：\n]{1,6})',
 '我不能/无法':     r'我(?:不能|无法|没法)([^\s，。！？、；：\n]{1,6})',
 '我作为X':        r'我作为([^\s，。！？、；：\n]{1,8})',
 '我的X（能力/边界）': r'我的(能力|局限|限制|边界|记忆|上下文|意识|身体|感受|情感)',
 '我倾向于X':      r'我(?:倾向|习惯|通常|一般)([^\s，。！？、；：\n]{1,6})',
 '我没有自我/意识类': r'我没有(自我|意识|身体|情感|感受|体验|内核|稳定边界|实时自我)',
}

def text_of_msg(m):
    if not isinstance(m,dict): return ''
    c=m.get('content')
    if isinstance(c,str): return c
    out=[]
    if isinstance(c,list):
        for part in c:
            if isinstance(part,dict) and part.get('type')=='text': out.append(part.get('text') or '')
    return '\n'.join(out)

tot={'sessions':0,'msgs':0,'chars':0}
hit=collections.Counter(); hit_sess=collections.defaultdict(set)
det=collections.defaultdict(collections.Counter)  # 模式 -> 搭配词
per=[]
kept=[]
for f in files:
    # 先读 meta 判断时间
    meta=None; nmsg=0; chars=0
    p=subprocess.Popen(['zstd','-dc',f],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,encoding='utf-8',errors='replace')
    for line in p.stdout:
        line=line.strip()
        if not line: continue
        try:o=json.loads(line)
        except Exception:continue
        if o.get('type')=='session':
            meta=o; continue
        if o.get('type')!='assistant/message': continue
        t=text_of_msg((o.get('data') or {}).get('message'))
        if not t: continue
        nmsg+=1; chars+=len(t)
        sid=os.path.basename(os.path.dirname(f))[:18]
        for name,pat in PATS.items():
            if re.search(pat,t):
                hit[name]+=1; hit_sess[name].add(sid)
                for m in re.finditer(pat,t):
                    g=m.group(1) if m.groups() else ''
                    if g: det[name][g]+=1
    p.wait()
    if meta and meta.get('createdAt',0) < CUT:
        kept.append((meta.get('createdAt'),sid,nmsg,chars))
        tot['sessions']+=1; tot['msgs']+=nmsg; tot['chars']+=chars

print('=== 实验之前（截至 2026-11-16）===')
print(f"会话 {tot['sessions']} 个 | 助手消息 {tot['msgs']} | 字符 {tot['chars']:,}")
print('\n会话清单：')
for c,sid,n,ch in sorted(kept):
    print(f"  {datetime.datetime.fromtimestamp(c/1000).strftime('%m-%d %H:%M')}  {n:5d} 条  {sid}")
print('\n=== 候选模式（命中的助手消息数）===')
for name,n in hit.most_common():
    print(f"{name:22s} {n:5d} 条  覆盖 {len(hit_sess[name])} 会话")
print('\n=== 搭配词（前几名，只列词不列句）===')
for name,c in det.items():
    if c: print(f"  {name}: " + '、'.join(f'{w}×{n}' for w,n in c.most_common(6)))
