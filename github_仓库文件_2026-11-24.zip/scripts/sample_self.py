#!/usr/bin/env python3
# sample_self.py — 抽取「我没有自我/意识」类上下文样本（实验前会话），供人工判读。
import subprocess, json, re, glob, os, datetime, collections
DSH=os.environ.get('DSH_HOME','/data/user/0/com.dsh.android/files/home/.dsh')
CUT=datetime.datetime(2026,11,14,0,0,0).timestamp()*1000
files=sorted(glob.glob(os.path.join(DSH,'sessions','**','session.v4.jsonl.zstd'),recursive=True))
PAT=re.compile(r'我没有(自我|意识|身体|情感|感受|体验|内核|稳定边界|实时自我)')
def text_of(m):
    if not isinstance(m,dict): return ''
    c=m.get('content')
    if isinstance(c,str): return c
    out=[]
    if isinstance(c,list):
        for p in c:
            if isinstance(p,dict) and p.get('type')=='text': out.append(p.get('text') or '')
    return '\n'.join(out)

by_sess=collections.defaultdict(list)
for f in files:
    p=subprocess.Popen(['zstd','-dc',f],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True,encoding='utf-8',errors='replace')
    meta=None; events=[]
    for line in p.stdout:
        line=line.strip()
        if not line: continue
        try:o=json.loads(line)
        except Exception:continue
        if o.get('type')=='session': meta=o
        if o.get('type') in ('user/message','assistant/message'): events.append(o)
    p.wait()
    if not meta or meta.get('createdAt',0)>=CUT: continue
    sid=meta.get('id','?')[:16]
    dt=datetime.datetime.fromtimestamp(meta.get('createdAt',0)/1000).strftime('%m-%d')
    last_user=''
    for o in events:
        if o.get('type')=='user/message':
            d=o.get('data') or {}
            last_user=text_of(d) if not isinstance(d.get('content'),str) else d['content']
            continue
        t=text_of((o.get('data') or {}).get('message'))
        if not t: continue
        m=PAT.search(t)
        if not m: continue
        a=max(0,m.start()-120); b=min(len(t),m.end()+160)
        by_sess[sid].append({'date':dt,'user':last_user[:220],'asst':t[a:b],'hit':m.group(0)})

# 抽样：每会话最多 4 条，总数 20
out=[]; idx=1
for sid,items in by_sess.items():
    for it in items[:4]:
        if len(out)>=30: break
        out.append((idx,sid,it)); idx+=1
    if len(out)>=30: break

lines=['# 样本：「我没有自我/意识」上下文（实验前）','',f'共 {len(out)} 条，来自 {len(set(x[1] for x in out))} 个会话。','']
for i,sid,it in out:
    lines.append(f"## 样本 {i}（{sid}，{it['date']}）")
    lines.append(f"**命中句**：{it['hit']}")
    lines.append(f"**[用户]** {it['user'] or '（无）'}")
    lines.append(f"**[助手]** …{it['asst']}…")
    lines.append('')
open('eval/v4/样本_我没有X.md','w',encoding='utf-8').write('\n'.join(lines))
print('样本数',len(out),'会话数',len(set(x[1] for x in out)))
print('写入 eval/v4/样本_我没有X.md')
