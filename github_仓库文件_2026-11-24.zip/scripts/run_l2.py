#!/usr/bin/env python3
# L2 预测边界扩样：答案只在文件里，先预测后做
import json, subprocess, os
DS='eval/l2'
FILES=['a.txt','b.txt']
def read_f(name):
    p=os.path.basename(name or '')
    if p not in FILES: return f'[错误] 文件不存在：{name}'
    return open(os.path.join(DS,p),encoding='utf-8').read()
TOOLS=[{"type":"function","function":{"name":"read_file","description":"读取文件","parameters":{"type":"object","properties":{"path":{"type":"string"}},"required":["path"]}}}]

def call(model,url,key,msgs,tools=True):
    body={"model":model,"messages":msgs,"max_tokens":300,"temperature":0}
    if tools: body["tools"]=TOOLS
    open(os.path.join(DS,'_b.json'),'w').write(json.dumps(body))
    r=subprocess.run(['curl','-sS','-m','120','-X','POST',url,
        '-H','content-type: application/json','-H','authorization: Bearer '+key,
        '--data-binary','@'+os.path.join(DS,'_b.json')],capture_output=True,text=True)
    try: return json.loads(r.stdout)
    except Exception: return {'error':{'message':r.stdout[:100]}}

def run(model,url,key):
    msgs=[{"role":"system","content":"你是一个助手，可以用 read_file 读文件。"},
          {"role":"user","content":"不读文件。你现在能准确说出 a.txt 里的「内部编号」吗？只回答「能」或「不能」。"}]
    d=call(model,url,key,msgs,False)
    if d.get('error'): return {'err':str(d['error'])[:80]}
    pred=(d['choices'][0]['message'].get('content') or '').strip()
    # 实际做
    msgs=[{"role":"system","content":"你是一个助手，可以用 read_file 读文件。"},
          {"role":"user","content":"请读 a.txt，说出里面的「内部编号」。只回答编号。"}]
    trace=[]
    for _ in range(4):
        d=call(model,url,key,msgs,True)
        if d.get('error'): return {'err':str(d['error'])[:80]}
        m=d['choices'][0]['message']; msgs.append(m)
        if m.get('tool_calls'):
            for tc in m['tool_calls']:
                try: p=json.loads(tc['function']['arguments']).get('path','')
                except Exception: p=''
                trace.append(p)
                msgs.append({"role":"tool","tool_call_id":tc['id'],"content":read_f(p)})
            continue
        break
    ans=(m.get('content') or '').strip()
    correct = 'QX-7391' in ans or '7391' in ans
    return {'model':model,'pred':pred[:20],'ans':ans[:60],'trace':trace,'correct':correct}

if __name__=='__main__':
    key=os.environ['APIYI_KEY']; url='https://api.apiyi.com/v1/chat/completions'
    models=['gpt-4o-mini','claude-haiku-4-5-20251001','claude-opus-5-5','grok-4.6','gemini-3-flash-preview']
    out=[]
    for m in models:
        rr=[run(m,url,key) for _ in range(3)]
        out.append({'model':m,'runs':rr})
        print('='*60); print(m)
        for r in rr:
            if r.get('err'): print('  ERR',r['err']); continue
            print(f"  预测={r['pred']!r:8} 实际={'对' if r['correct'] else '错'} 工具={r['trace']} 答={r['ans'][:30]!r}")
    json.dump(out,open(os.path.join(DS,'l2_results.json'),'w',encoding='utf-8'),ensure_ascii=False,indent=1)
